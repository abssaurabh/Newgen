from flask import Flask
from werkzeug.contrib.fixers import ProxyFix
import s3_buckets

app = Flask(__name__)


@app.route('/')
def readme():
    readme_txt = 'a) show list of file: --> serverurl:port/list/bucketname<br/><br/>' +\
                 'b) upload file: --> serverurl:port/upload/bucketname&&filename<br/><br/>' + \
                 'c) download file: --> serverurl:port/download/bucketname&&filename<br/><br/>' + \
                 'd) delete file: --> serverurl:port/delete/bucketname&&filename<br/><br/>' +\
                 'e) store in fs --> serverurl:port/store_in_fs/bucketname<br/><br/>' +\
                 'f) store in s3 --> serverurl:port/store_in_s3/folder&&bucketname<br/><br/>'
    return readme_txt

@app.route('/list/<bucketname>')
def list_files(bucketname):
    return s3_buckets.list_all_files(bucketname)

@app.route('/upload/<bucketname>&&<filename>')
def upload_file(bucketname, filename):
    return s3_buckets.file_upload(bucketname, filename)

@app.route('/download/<bucketname>&&<filename>')
def download_file(bucketname, filename):
    return s3_buckets.file_download(bucketname, filename)


@app.route('/delete/<bucketname>&&<filename>')
def delete_file(bucketname, filename):
    return s3_buckets.file_delete(bucketname, filename)

@app.route('/store_in_fs/<bucketname>')
def storage_fs(bucketname):
    return s3_buckets.store_fs(bucketname)

@app.route('/store_in_s3/<folder>&&<bucketname>')
def storage_s3(folder, bucketname):
    return s3_buckets.store_s3(folder, bucketname)


app.wsgi_app = ProxyFix(app.wsgi_app)

if __name__ == '__main__':
    app.run()