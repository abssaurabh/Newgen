import boto3
import json
import os

#prefix is taken default as ''

def list_all_files(bucketname, prefix =''):
    s3_client = boto3.client('s3')
    # List all objects within a S3 bucket path
    response = s3_client.list_objects(
        Bucket=bucketname,
        Prefix=prefix
    )
    # Loop through each file
    file_list = []
    for file in response['Contents']:
        # Get the file name
        name = file['Key'].rsplit('/', 1)
        file_list.append(name[0])

    return json.dumps(file_list)


def file_upload(bucketname, filename, prefix= ''):
    s3 = boto3.resource('s3')
    data = open(filename, 'rb')
    s3.Bucket(bucketname).put_object(Key= filename, Body=data)
    return "Successfully uploaded "+ filename + " to " + bucketname

def file_download(bucketname, filename, prefix= ''):
    s3 = boto3.resource('s3')
    s3.Bucket(bucketname).download_file(filename, filename)
    return "Successfully downloaded "+ filename + " from " + bucketname


def file_delete(bucketname, filename, prefix= ''):
    s3_client = boto3.client('s3')
    s3_client.delete_object(Bucket=bucketname, Key=filename)
    return "Successfully deleted " + filename + " from " + bucketname

def store_fs(bucketname, prefix =''):
    s3_client = boto3.client('s3')
    s3 = boto3.resource('s3')
    response = s3_client.list_objects(
        Bucket=bucketname,
        Prefix=prefix
    )
    for file in response['Contents']:
        name = file['Key'].rsplit('/', 1)
        s3.Bucket(bucketname).download_file(str(name[0]), str(name[0]))
        file_delete(bucketname, str(name[0]))
    return "Successfully downloaded to FS and deleted in S3"


def store_s3(folder,bucketname, prefix =''):
     s3 = boto3.resource('s3')
     for x,y,filenames in os.walk(folder):
        for file in filenames:
            data = open(folder+'/'+str(file), 'rb')
            s3.Bucket(bucketname).put_object(Key=str(file), Body=data)
            os.remove(folder+'/'+str(file))
     return "Successfully uploaded to S3 and deleted in FS"