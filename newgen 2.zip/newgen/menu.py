from flask import Flask
from flask import request
import os
from werkzeug.contrib.fixers import ProxyFix
import s3_buckets
import fs_buckets

app = Flask(__name__)
LOCAL_FS = os.path.join(os.path.expanduser('~'),"LOCALFS")
# storage can be 'S3' or 'RDS'
STORAGE = ['S3','RDS']
storage_index = 0


@app.route('/')
def readme():
    readme_txt = 'a) show list of file: --> serverurl:port/list/bucketname<br/><br/>' +\
                 'b) upload file: --> serverurl:port/upload/bucketname&&filename<br/><br/>' + \
                 'c) download file: --> serverurl:port/download/bucketname&&filename<br/><br/>' + \
                 'd) delete file: --> serverurl:port/delete/bucketname&&filename<br/><br/>' +\
                 'e) store in fs --> serverurl:port/store_in_fs/bucketname<br/><br/>' +\
                 'f) store in s3 --> serverurl:port/store_in_s3/folder&&bucketname<br/><br/>'
    return readme_txt


@app.route('/current_store', methods=['GET'])
def current_store():
    return STORAGE[storage_index]


@app.route('/list', methods=['GET'])
def list_files():
    bucketname = request.args.get('bucketname')
    if STORAGE[storage_index]=='S3':
        return s3_buckets.s3_list_all_files(bucketname)
    else:
        return fs_buckets.fs_list_all_files(bucketname)


@app.route('/upload', methods =['POST'])
def upload_file():
    bucketname = request.args.get('bucketname')
    prefix = request.args.get('prefix')
    abs_file_path = request.args.get('filename')
    if STORAGE[storage_index] == 'S3':
        return s3_buckets.s3_file_upload(abs_file_path, prefix, bucketname)
    else:
        return fs_buckets.fs_file_upload(abs_file_path, prefix, bucketname)


@app.route('/download', methods =['GET'])
def download_file():
    bucketname = request.args.get('bucketname')
    filename = request.args.get('filename')
    prefix = request.args.get('prefix')
    if STORAGE[storage_index] == 'S3':
        return s3_buckets.s3_file_download(filename, prefix, bucketname)
    else:
        return fs_buckets.fs_file_download(filename, prefix, bucketname)


@app.route('/delete', methods=['DELETE'])
def delete_file():
    bucketname = request.args.get('bucketname')
    filename = request.args.get('filename')
    prefix = request.args.get('prefix')
    if STORAGE[storage_index] == 'S3':
        return s3_buckets.s3_file_delete(filename, prefix, bucketname)
    else:
        return fs_buckets.fs_file_delete(filename, prefix, bucketname)


@app.route('/switch_store', methods=['GET','POST','DELETE'])
def storage_switch():
    global storage_index
    global LOCAL_FS
    global STORAGE
    storage_index = storage_index ^ 1
    change_store_to = STORAGE[storage_index]
    bucketname = request.args.get('bucketname')
    if change_store_to == 'S3':
        return s3_buckets.store_s3(bucketname)
    elif change_store_to == 'RDS':
        return fs_buckets.store_fs(bucketname)
    else:
        return "ERROR: Not a valid store"


app.wsgi_app = ProxyFix(app.wsgi_app)

if __name__ == '__main__':
    app.run()