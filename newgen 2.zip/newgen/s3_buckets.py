import boto3
import json
import os
from flask import jsonify
from flask import abort

LOCAL_FS = os.path.join(os.path.expanduser('~'),"LOCALFS")


def bad_request(bucketname, filename):
    # bad request
    if bucketname is None or filename is None:
        return True
    else:
        return False


def s3_keyname(prefix, filename):
    # check if file is part of a sub-folder in s3
    if prefix is None:
        s3keyname = filename
    else:
        s3keyname = str("{0}/{1}".format(prefix, filename))
    return s3keyname


def s3_list_all_files(bucketname):
    if bucketname is None:
        return abort(400)
    else:
        s3_client = boto3.client('s3')
        try:
            response = s3_client.list_objects(
                    Bucket=bucketname,
                    Prefix=''
                    )
        except:
            return abort(400)
        file_list = []
        for file in response['Contents']:
            filename = file['Key']
            file_list.append(filename)

        return jsonify(file_list)


def s3_file_upload(abs_filepath, prefix, bucketname):
    # check bad request
    if bad_request(bucketname, abs_filepath):
        return abort(400)
    s3 = boto3.resource('s3')
    filename = abs_filepath.split('/')[-1]
    keyname = s3_keyname(prefix, filename)
    try:
        with open(abs_filepath, 'rb') as data:
            s3.Bucket(bucketname).put_object(Key=keyname, Body=data)
            return str("Successfully uploaded {0:s} to bucket: {1:s}"
                       .format(filename, bucketname)
                       )
    except :
        return abort(400)


def s3_file_download(filename, prefix, bucketname):
    s3 = boto3.resource('s3')

    # check bad request
    if bad_request(bucketname, filename):
        return abort(400)

    else:
        # check if file is part of sub-folder in s3
        keyname = s3_keyname(prefix, filename)
        # create download folders
        s3_downloads = os.path.join(os.path.expanduser('~'), "s3/downloads/")
        if not os.path.exists(s3_downloads):
            os.makedirs(s3_downloads)

        # provide full path for the local file
        filename = os.path.join(s3_downloads,filename)

        # download file as a local copy
        try:
            s3.Bucket(bucketname).download_file(keyname, filename)
            return str("Successfully downloaded to {0} from s3 bucket: {1}".format(filename,bucketname))
        except :
            return abort(404)


def s3_file_delete(filename, prefix, bucketname):
    #check bad request
    if bad_request(bucketname, filename):
        return abort(400)
    else:
        keyname = s3_keyname(prefix, filename)
        try:
            s3_client = boto3.client('s3')
            s3_client.delete_object(Bucket=bucketname, Key=keyname)
            return "Successfully deleted " + filename + " from " + bucketname
        except:
            return abort(404)



def store_s3(bucketname):
     s3 = boto3.resource('s3')
     fs_folder = LOCAL_FS
     for x,y,filenames in os.walk(fs_folder):
        for file in filenames:
            data = open(fs_folder+'/'+str(file), 'rb')
            s3.Bucket(bucketname).put_object(Key=str(file), Body=data)
            os.remove(fs_folder+'/'+str(file))
     return "Successfully uploaded to S3 and deleted in LOCALFS"