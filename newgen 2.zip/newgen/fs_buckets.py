import boto3
import s3_buckets
import json
import os
from shutil import copy2
from flask import jsonify
from flask import abort

LOCAL_FS = os.path.join(os.path.expanduser('~'),"LOCALFS")

def bad_request(bucketname, filename):
    # bad request
    if bucketname is None or filename is None:
        return True
    else:
        return False


def fs_filename(prefix, filename):
    # check if file is part of a sub-folder in s3
    if prefix is None:
        fs_filename = filename
    else:
        fs_filename = str("{0}/{1}".format(prefix, filename))
    return fs_filename


def fs_list_all_files(bucketname):
    if bucketname is None:
        return abort(400)
    else:
        file_list = []
        global LOCAL_FS
        bucket_location = os.path.join(LOCAL_FS, bucketname)
        try:
            for path, subdirs, files in os.walk(bucket_location):
                for dirs in subdirs:
                    file_list.append(os.path.join(path, dirs))
                for name in files:
                    file_list.append(os.path.join(path, name))
        except:
            return abort(400)
        return jsonify(file_list)


def fs_file_upload(abs_filepath, prefix, bucketname):
    # check bad request
    if bad_request(bucketname, abs_filepath):
        return abort(400)
    filename = abs_filepath.split('/')[-1]
    try:
            fs_location = os.path.join(LOCAL_FS, bucketname, prefix)
            copy2(abs_filepath, fs_location)
            return str("Successfully uploaded {0:s} to folder: {1:s} on LOCALFS"
                       .format(filename, bucketname)
                       )
    except :
        return abort(400)


def fs_file_download(filename, prefix, bucketname):
    # check bad request
    if bad_request(bucketname, filename):
        return abort(400)
    else:
        filename = os.path.join(LOCAL_FS, bucketname, prefix, filename)
        # create download folders
        fs_downloads = os.path.join(os.path.expanduser('~'), "fs/downloads/", bucketname, prefix)
        if not os.path.exists(fs_downloads):
            os.makedirs(fs_downloads)

        # download file as a local copy
        try:
            copy2(filename, fs_downloads)
            return str("Successfully downloaded to {0} from s3 bucket: {1}".format(filename,bucketname))
        except :
            return abort(404)


def fs_file_delete(filename, prefix, bucketname):
    #check bad request
    if bad_request(bucketname, filename):
        return abort(400)
    else:
        filename = os.path.join(LOCAL_FS, bucketname, prefix, filename)
        try:
            os.remove(filename)
            return "Successfully deleted " + filename + " from " + bucketname
        except:
            return abort(404)


def store_fs(bucketname):
    if bucketname is None:
        return abort(400)
    s3_client = boto3.client('s3')
    s3 = boto3.resource('s3')
    response = s3_client.list_objects(
                    Bucket=bucketname,
                    Prefix=''
                )
    for file in response['Contents']:
        filename = file['Key']
        if '/' in filename:
            continue
        prefix = ''
        fs_file_dir = os.path.join(LOCAL_FS, bucketname)
        if not os.path.exists(fs_file_dir):
            os.makedirs(fs_file_dir)
        fs_file_loc = os.path.join(LOCAL_FS, bucketname, filename)
        print(filename)
        try:
            print(filename)
            s3.Bucket(bucketname).download_file(filename, fs_file_loc)
            s3_buckets.s3_file_delete(filename, prefix, bucketname)
        except:
            return abort(400)
    return "Successfully downloaded to LOCALFS and deleted in S3"

