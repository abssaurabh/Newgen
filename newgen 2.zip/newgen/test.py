from shutil import copy2
copy2('/Users/abs/Desktop/testfile1.txt','/Users/abs/LOCALFS/newgenbucket/')
